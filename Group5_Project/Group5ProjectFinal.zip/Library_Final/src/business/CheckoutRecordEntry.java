package business;

import java.io.Serializable;
import java.time.LocalDate;

public class CheckoutRecordEntry implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7647940524688830424L;
	private LocalDate checkoutDate;
	private LocalDate dueDate;
	private BookCopy bookCopy;
	private String entryRecordId;
	
	public CheckoutRecordEntry(String erId, Book book, int copyNum, LocalDate chD, LocalDate dD){
		//System.out.println("INSIDE CHECOUT RECORD ENTRY");
		this.entryRecordId = erId;
		this.checkoutDate = chD;
		this.dueDate = dD;
		this.bookCopy = book.getCopy(copyNum);
		//System.out.println(this.bookCopy);
	}
	
	public String getEntryRecordId() {
		return this.entryRecordId;
	}
	
	public BookCopy getBookCopy() {
		return this.bookCopy;
	}

	public LocalDate getCheckoutDate() {
		return checkoutDate;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}
	public void setDueDate(LocalDate ld) {
		this.dueDate = ld;
	}
	public void setCheckoutDate(LocalDate chd) {
		this.checkoutDate = chd;
	}
	@Override
	public String toString() {
		return "Checkout Record Entry: " + entryRecordId + " " + checkoutDate + " " + dueDate + " " + bookCopy;
	}
}
