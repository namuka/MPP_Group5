package ui;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import business.Author;
import business.Book;
import business.SystemController;
import dataaccess.DataAccess;
import dataaccess.DataAccessFacade;
import dataaccess.TestData;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import util.Messages;

public class BookController implements Initializable{
	
	@FXML
	private TextField tfBookTitle;
    @FXML
    private TextField tfBookIsbn;
    @FXML
    private TextField tfBookCopies;
    @FXML
    private TextField tfBookMax;
    @FXML
    private ListView<Author> lvBookAuthors;
    
    @FXML
    private Button btnBookFormCancel;
    @FXML
    private Button btnBookFormSave;
    @FXML
    private Text txtBookForm;
    @FXML 
    private ComboBox<String> comboMaxLength;
    
    @FXML
    private TextArea txtAuthorsInfo;
    
    private SystemController ctl=new SystemController();

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		tfBookCopies.setText("1");
		tfBookCopies.setDisable(true);
		lvBookAuthors.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    	final ObservableList<Author> strings = FXCollections.observableArrayList();  
    	
    	List<Author> allAuthors = ctl.getAuthors();            	
    	for(Author a: allAuthors) {
    		 strings.add(a);  
 		}                                    	
    	lvBookAuthors.setItems(strings);    	
    	
    	tfBookCopies.textProperty().addListener(new ChangeListener<String>() {
    	    @Override
    	    public void changed(ObservableValue<? extends String> observable, String oldValue, 
    	        String newValue) {
    	        if (!newValue.matches("\\d*")) {
    	        	tfBookCopies.setText(newValue.replaceAll("[^\\d]", ""));
    	        }
    	    }
    	});
    	
    	comboMaxLength.getItems().add("21");
    	comboMaxLength.getItems().add("7");
    	
	}
	
	public void initData(Book b) {
		tfBookTitle.setText(b.getTitle());
		tfBookIsbn.setText(b.getIsbn());
		//tfBookMax.setText(String.valueOf(b.getMaxCheckoutLength()));
		comboMaxLength.setValue(String.valueOf(b.getMaxCheckoutLength()));
		int numCopies = b.getNumCopies()>0 ? b.getNumCopies() : 1;
		tfBookCopies.setText(String.valueOf(numCopies));
		
    	List<Author> allAuthors = ctl.getAuthors();
    	int i = 0; 
    	List<Author> alist = b.getAuthors();
    	StringBuilder authorsInfo =  new StringBuilder();
		for(Author a: allAuthors) {                                   		 
      		 for(Author a2: alist) {
      			 if(a.getFirstName().equals(a2.getFirstName())) {
      				lvBookAuthors.getSelectionModel().select(i);
      				authorsInfo.append(a.getFirstName() + " " + a.getLastName() + " Phone: " + a.getTelephone() + " Bio: " + a.getBio() + "\n");
      	    		 authorsInfo.append("Address: " + a.getAddress().getState() + ", " + a.getAddress().getCity() + ", " + a.getAddress().getStreet() +", " + a.getAddress().getZip());
      	    		 authorsInfo.append("\n");
      			 }
      		 }
      		 i+=1;
   		} 
		txtAuthorsInfo.setText(authorsInfo.toString());
	}
	
	public void addBook(ActionEvent actionEvent) {
		try {
			//DataAccess da = new DataAccessFacade();
			List<Author> alist2 = new ArrayList<>();
			//System.out.println(tf5.getSelectionModel().getSelectedItems());
			for(Author a2: lvBookAuthors.getSelectionModel().getSelectedItems()) {                                    			
				alist2.add(a2);
				
			}
			boolean isValid = true;
			//Checking fields are empty or not
			if(tfBookIsbn.getText()==null || tfBookIsbn.getText().isEmpty()) {
				isValid=false;
				Messages.showAlertDialog(Alert.AlertType.ERROR, "Error", "ERROR!", "Please enter ISBN");
			}
				
			if(tfBookTitle.getText()==null || tfBookTitle.getText().isEmpty()) {
				isValid=false;
				Messages.showAlertDialog(Alert.AlertType.ERROR, "Error", "ERROR!", "Please enter Title");
			}
			/*if(tfBookMax.getText()==null || tfBookMax.getText().isEmpty()) {
				isValid=false;
				Messages.showAlertDialog(Alert.AlertType.ERROR, "Error", "ERROR!", "Please enter Max checkout length");
			}*/
			if(comboMaxLength.getValue()==null || comboMaxLength.getValue().isEmpty()) {
				isValid=false;
				Messages.showAlertDialog(Alert.AlertType.ERROR, "Error", "ERROR!", "Please select Max checkout length");
			}
			
			if(isValid==true) {
				//Book newBook = new Book(tfBookIsbn.getText(),tfBookTitle.getText(), Integer.parseInt(tfBookMax.getText()), alist2);
				ctl.addBook(tfBookIsbn.getText(),tfBookTitle.getText(), Integer.parseInt(comboMaxLength.getValue()), alist2);
				txtBookForm.setStyle("-fx-background-color: #E1ECF4;");
				txtBookForm.setStyle("-fx-fill: #0f9d58;");
				txtBookForm.setText("Successfully saved!");			
				
		    	/*FXMLLoader loader = new FXMLLoader(getClass().getResource("Home.fxml"));		    	   
		    	HomeController hc = loader.getController();		
		    	hc.updateBookings();*/
				/*FXMLLoader loader = new FXMLLoader();
		         
		        loader.setLocation(getClass().getResource("Home.fxml"));
		        HomeController hc = new HomeController();
		        loader.setController(hc); 
		        hc.updateBookings();*/
				       
				//tb_books.refresh();
			}
			else {
				txtBookForm.setStyle("-fx-fill: red;");
				txtBookForm.setText("Not saved!");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void closeWindow(ActionEvent actionEvent) {
		Stage stage = (Stage) btnBookFormCancel.getScene().getWindow();
        stage.close();
	}

}
