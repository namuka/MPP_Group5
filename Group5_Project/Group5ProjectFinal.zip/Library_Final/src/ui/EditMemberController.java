package ui;

import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Random;
import java.util.ResourceBundle;

import business.Address;
import business.LibraryMember;
import business.SystemController;
import dataaccess.DataAccessFacade;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import util.Messages;

public class EditMemberController implements Initializable {

	@FXML
	private TextField firstNameField;
	@FXML
	private TextField lastNameField;
	@FXML
	private TextField streetField;
	@FXML
	private TextField postalCodeField;
	@FXML
	private TextField cityField;
	@FXML
	private TextField stateField;
	@FXML
	private TextField telephoneField;
	@FXML
	private TextField memberIDField;
	
	@FXML
	private Button editbtn;
		
	public static LibraryMember lmem=null;
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		if(lmem!=null) {
			firstNameField.setText(lmem.getFirstName());
			lastNameField.setText(lmem.getLastName());
			streetField.setText(lmem.getAddress().getStreet());
			cityField.setText(lmem.getAddress().getCity());
			postalCodeField.setText(lmem.getAddress().getZip());
			stateField.setText(lmem.getAddress().getState());
			telephoneField.setText(lmem.getTelephone());
			memberIDField.setText(lmem.getMemberId());
		}
	}
	
	public void editMemeber(ActionEvent actionEvent) {
		String msg=null;
		if(streetField.getText().isEmpty()||cityField.getText().isEmpty()|| stateField.getText().isEmpty()|| postalCodeField.getText().isEmpty()||memberIDField.getText().isEmpty()|| firstNameField.getText().isEmpty()|| lastNameField.getText().isEmpty()|| telephoneField.getText().isEmpty()) {
			Messages.showAlertDialog(Alert.AlertType.ERROR, "Error", "ERROR!","There is Empty Field");
		}else{
			SystemController ctl=new SystemController();
			ctl.addNewMember(memberIDField.getText(), firstNameField.getText(), lastNameField.getText(), telephoneField.getText(),streetField.getText(), cityField.getText(), stateField.getText(), postalCodeField.getText());
			Stage stage = (Stage) editbtn.getScene().getWindow();
	        stage.close();
		}
	}

}
