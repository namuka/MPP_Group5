//This is a note from the team responsible for this project.
//It tells the professor about any extra work that was done or other things
//that need to be mentioned.

/***********Professor's comment**********/
1. Show author info in the "Book Edit" window
We added "Authors info" compenent in the "Book Edit" window.

2. Show book copy info in the "Checkout Records" TableView.
We added following columns in the TableView: Book title, Copy num;



/***********Extra work***********/

1. Given a library member id, print the checkout record of that libray member
To do this we added "Print" button in the TableView's each row.
if you click on the "Print" button, you will see the Alert dialog and info will be printed in the console.


2. Determine wheter a given copy of publication is overdue, and which library member has it in his/her possession.
To do this we added another column called "Overdue" in the TableView of the "Checkour Records" menu.
If the copy of book is overdue, in this column we will show the text info "Overdue".
Also if you click on the "Show detail" button, you will see the Checkout details info in the new window.