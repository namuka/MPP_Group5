package ui;

import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Random;
import java.util.ResourceBundle;

import business.Address;
import business.LibraryMember;
import dataaccess.DataAccessFacade;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class NewMemberController implements Initializable {

	@FXML
	private TextField firstNameField;
	@FXML
	private TextField lastNameField;
	@FXML
	private TextField streetField;
	@FXML
	private TextField postalCodeField;
	@FXML
	private TextField cityField;
	@FXML
	private TextField stateField;
	@FXML
	private TextField telephoneField;
	@FXML
	private TextField memberIDField;
	
	@FXML
	private Button addbtn;
	
	private double x, y;
	
	public static final String SOURCES ="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		char[] text = new char[7];
        for (int i = 0; i < 7; i++) {
            text[i] = SOURCES.charAt(new Random().nextInt(SOURCES.length()));
        }
	    memberIDField.setText(text.toString());
	}
	
	public void addMemeber(ActionEvent actionEvent) {
		Address ad=new Address(streetField.getText(), cityField.getText(), stateField.getText(), postalCodeField.getText());
		LibraryMember member=new LibraryMember(memberIDField.getText(), firstNameField.getText(), lastNameField.getText(), telephoneField.getText(), ad);
		DataAccessFacade da=new DataAccessFacade();
		da.saveNewMember(member);
		Stage stage = (Stage) addbtn.getScene().getWindow();
        stage.close();
        //new HomeController().getMemberView();
    
	}

}
