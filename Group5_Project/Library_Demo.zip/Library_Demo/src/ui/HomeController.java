package ui;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;


import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import business.Author;
import business.Book;
import business.BookCopy;
import business.CheckoutRecord;
import business.LibraryMember;
import business.SystemController;
import dataaccess.Auth;
import dataaccess.DataAccess;
import dataaccess.DataAccessFacade;
import dataaccess.TestData;

public class HomeController implements Initializable {

	@FXML
    private VBox pnItems = null;
    //---menue buttons
    @FXML
    private Button btnMembers;
    @FXML
    private Button btnBooks;
    @FXML
    private Button btnCheckout;
    @FXML
    private Button btnCheckoutRecords;
    @FXML
    private Button btnLogout;

  //---refesh btns
    @FXML
    private Button rmem;
    @FXML
    private Button rbook;
    @FXML
    private Button rcb;
    @FXML
    private Button rco;

  //--------panels
    @FXML
    private Pane pnlMembers;

    @FXML
    private Pane pnlBooks;

    @FXML
    private Pane pnlCheckout;
    
    @FXML
    private Pane pnlCheckoutRecords;

    
    @FXML
    private Pane pnlHome;
    
    @FXML
    private Label welcome;
    
  //-------------member table view
    @FXML
    private Button btnNewMember;
    @FXML
    private Button editMember;
    
    @FXML
    private TableView<LibraryMember> tb;
    
    @FXML
    private TableColumn<LibraryMember, String> memberIdf;
    @FXML
    private TableColumn<LibraryMember, String> firstName;
    @FXML
    private TableColumn<LibraryMember, String> lastName;
    @FXML
    private TableColumn<LibraryMember, String> telephone;
    @FXML
    private TableColumn<LibraryMember, String> address;

    private double x, y;
    
    /*START: Books Panel Components*/
    @FXML 
    TableView<Book> tb_books;    
    @FXML
    private TableColumn<Book, String> bTitle;
    @FXML
    private TableColumn<Book, String> isbn;
    @FXML
    private TableColumn<Book, String> bAuthors;
    @FXML
    private TableColumn<Book, Integer> maxCheckoutLen;
    @FXML
    private TableColumn<Book, Integer> numOfCopies; 
    @FXML
    private TextField tfSearchBook;
    @FXML
    private Button btnSearchBook;
    @FXML
    private TextField tfBookCopies;
    @FXML
    private Button btnAddBook;
    /*END: Books Panel Components*/
    
    //******Checkout *****
    /*START: Books Panel Components*/
    @FXML 
    TableView<Book> chk_books;    
    @FXML
    private TableColumn<Book, String> cTitle;
    @FXML
    private TableColumn<Book, String> cAuthor;
    
    @FXML
    private TableColumn<Book, String> cisbn;
    @FXML
    private TableColumn<Book, Integer> cmaxCheckoutLen;
    @FXML
    private TableColumn<Book, Integer> cnumOfCopies; 
    @FXML
    private TableColumn<Book, String> availability; 
    
    @FXML
    private TextField ctfSearchBook;
    
    /*START: Records Panel Components*/
    @FXML 
    TableView<CheckoutRecord> rec_books;    
    @FXML
    private TableColumn<CheckoutRecord, String> rec_memberID;
    @FXML
    private TableColumn<CheckoutRecord, String> rec_isbn;
    @FXML
    private TableColumn<CheckoutRecord, String> rec_checkoutdate;
    @FXML
    private TableColumn<CheckoutRecord, String> rec_duedate;
    @FXML
    private TableColumn<CheckoutRecord, String> rec_btitle;
    @FXML
    private TableColumn<CheckoutRecord, String> rec_bcopynum;
    
    @FXML
    private TextField rec_SearchBook;
    
    
    SystemController ctl=new SystemController();
    @Override
    public void initialize(URL location, ResourceBundle rsoeurces) {
    	if(SystemController.currentAuth==Auth.BOTH) {
    		welcome.setText("Admin and Librarian");
    		pnlHome.toFront();
    	}else if(SystemController.currentAuth==Auth.LIBRARIAN) {
    		welcome.setText("Librarian");
    		btnMembers.setVisible(false);
    		btnBooks.setVisible(false);
    		pnlHome.toFront();
    	}else {
    		welcome.setText("Administrator");
    		btnCheckout.setVisible(false);
    		pnlHome.toFront();
    	}
    }
    
    public void getMemberView() {
    	ObservableList<LibraryMember> l= FXCollections.observableArrayList();
    	for(Map.Entry<String, LibraryMember> entry: ctl.allLibraryMember().entrySet()) {
    		l.add(entry.getValue());
    	}
    	memberIdf.setCellValueFactory(new PropertyValueFactory<LibraryMember, String>("memberId"));
    	firstName.setCellValueFactory(new PropertyValueFactory<LibraryMember,String>("firstName"));
    	lastName.setCellValueFactory(new PropertyValueFactory<LibraryMember,String>("lastName"));
    	telephone.setCellValueFactory(new PropertyValueFactory<LibraryMember,String>("telephone"));
    	address.setCellValueFactory(new PropertyValueFactory<LibraryMember,String>("address"));
    	tb.setItems(l);
    	pnlMembers.toFront();
    }
    
    public void getBooksView() {
    	ObservableList<Book> data = FXCollections.observableArrayList();        	
    	HashMap<String, Book> map = ctl.getBooks();
    	for(Map.Entry<String, Book> m: map.entrySet()) {
    		data.add(m.getValue());
    		
    	}
    	//System.out.println(data);
    	
    	bTitle.setCellValueFactory(new PropertyValueFactory<Book,String>("title"));
    	isbn.setCellValueFactory(new PropertyValueFactory<Book,String>("isbn"));
    	//bAuthors.setCellValueFactory(new PropertyValueFactory<Book,String>("authors"));
    	bAuthors.setCellValueFactory(cellData -> {
    		Book b = cellData.getValue();
    		List<Author> alist = b.getAuthors();
    		StringBuilder authorNames = new StringBuilder();
    		int i=0;
    		for(Author a: alist) {
    			if(i==0)
    			authorNames.append(a.getFirstName() + " " + a.getLastName());
    			else authorNames.append(", " + a.getFirstName() + " " + a.getLastName());
    			
    			i +=1;
    		}
    		return new SimpleStringProperty(authorNames.toString());
    	});
    	maxCheckoutLen.setCellValueFactory(new PropertyValueFactory<Book,Integer>("maxCheckoutLength"));
    	numOfCopies.setCellValueFactory(cellData -> {
    		Book b = cellData.getValue();
    		return new SimpleIntegerProperty(b.getNumCopies()).asObject();
    	});
    	
    	FilteredList<Book> filteredData = new FilteredList<>(data, p -> true);
    	tfSearchBook.textProperty().addListener((observable, oldValue, newValue) -> {
    		filteredData.setPredicate(book -> {
                // If filter text is empty, display all persons.
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                
                // Compare first name and last name of every person with filter text.
                String lowerCaseFilter = newValue.toLowerCase();
                
                if (book.getIsbn().toLowerCase().contains(lowerCaseFilter)) {
                    return true; // Filter matches first name.
                } 
                return false; // Does not match.
            });
        });
    	
    	
    	TableColumn actionCol = new TableColumn("Action");
        actionCol.setCellValueFactory(new PropertyValueFactory<>("DUMMY"));

        Callback<TableColumn<Book, String>, TableCell<Book, String>> cellFactory
                = //
                new Callback<TableColumn<Book, String>, TableCell<Book, String>>() {
            @Override
            public TableCell call(final TableColumn<Book, String> param) {
                final TableCell<Book, String> cell = new TableCell<Book, String>() {

                    final Button btn = new Button("Edit");
                    final Button btn2 = new Button("Add a copy");

                    @Override
                    public void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                            setText(null);
                        } else {    
                        	btn.setOnAction(e -> {
                        		Book book = getTableView().getItems().get(getIndex());
                        		Parent root;
								try {
									FXMLLoader loader = new FXMLLoader(getClass().getResource("FormBook.fxml"));
									root = loader.load();
									Stage primaryStage=new Stage();
	                                primaryStage.setScene(new Scene(root));
	                                BookController controller = loader.getController();
	                                controller.initData(book);
	                                	  
	                                root.setOnMousePressed(event -> {
	                                    x = event.getSceneX();
	                                    y = event.getSceneY();
	                                });
	                                root.setOnMouseDragged(event -> {

	                                    primaryStage.setX(event.getScreenX() - x);
	                                    primaryStage.setY(event.getScreenY() - y);

	                                });
	                                primaryStage.setTitle("Edit book information");
	                                primaryStage.show();
	                               
	                                
								} catch (IOException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}                                
                        	});  
                        	btn2.setOnAction(e -> {
                            	Book book = getTableView().getItems().get(getIndex());
								ctl.addBookCopy(book);
								Alert alert =  new Alert(AlertType.INFORMATION);
								alert.setTitle("Add a book copy information");
								alert.setContentText("Successfully added.");
								alert.showAndWait();
								
								tb_books.refresh();
                            	
                            }
                        	);
                        	
                        	HBox.setMargin(btn2,new Insets(0,5,0,10));                               
                            HBox pane = new HBox(btn, btn2);
                            setGraphic(pane);
                            //setGraphic(btn); 
                            setText(null);
                        }
                    }
                };
                return cell;
            }
        };

        actionCol.setCellFactory(cellFactory);
        
    	tb_books.setItems(filteredData);
    	tb_books.getColumns().setAll(bTitle,isbn,bAuthors,maxCheckoutLen, numOfCopies, actionCol);
    	pnlBooks.setStyle("-fx-background-color : #53639F");
    	pnlBooks.toFront();
    }
    
    public void getCheckoutView() {
    	ObservableList<Book> data = FXCollections.observableArrayList();        	
    	HashMap<String, Book> map = ctl.getBooks();
    	for(Map.Entry<String, Book> m: map.entrySet()) {
    		data.add(m.getValue());
    		
    	}
    	//System.out.println(data);
    	
    	cTitle.setCellValueFactory(new PropertyValueFactory<Book,String>("title"));
    	cisbn.setCellValueFactory(new PropertyValueFactory<Book,String>("isbn"));
    	//bAuthors.setCellValueFactory(new PropertyValueFactory<Book,String>("authors"));
    	cAuthor.setCellValueFactory(cellData -> {
    		Book b = cellData.getValue();
    		List<Author> alist = b.getAuthors();
    		StringBuilder authorNames = new StringBuilder();
    		int i=0;
    		for(Author a: alist) {
    			if(i==0)
    			authorNames.append(a.getFirstName() + " " + a.getLastName());
    			else authorNames.append(", " + a.getFirstName() + " " + a.getLastName());
    			
    			i +=1;
    		}
    		return new SimpleStringProperty(authorNames.toString());
    	});
    	availability.setCellValueFactory(cellData -> {
    		Book b = cellData.getValue();
    		BookCopy[] bc=b.getCopies();
    		String available="Not Available";
    		int count=0;
    		for(BookCopy a: bc) {
    			if(a.isAvailable()) {
    				count++;
    			}
    		}
    		available=count+" copies";
    		return new SimpleStringProperty(available);
    	});
    	cmaxCheckoutLen.setCellValueFactory(new PropertyValueFactory<Book,Integer>("maxCheckoutLength"));
    	cnumOfCopies.setCellValueFactory(cellData -> {
    		Book b = cellData.getValue();
    		return new SimpleIntegerProperty(b.getNumCopies()).asObject();
    	});
    	
    	FilteredList<Book> filteredData = new FilteredList<>(data, p -> true);
    	ctfSearchBook.textProperty().addListener((observable, oldValue, newValue) -> {
    		filteredData.setPredicate(book -> {
                // If filter text is empty, display all persons.
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                
                // Compare first name and last name of every person with filter text.
                String lowerCaseFilter = newValue.toLowerCase();
                
                if (book.getIsbn().toLowerCase().contains(lowerCaseFilter)) {
                    return true; // Filter matches first name.
                } 
                return false; // Does not match.
            });
        });
    	
    	
    	TableColumn actionCol = new TableColumn("Action");
        actionCol.setCellValueFactory(new PropertyValueFactory<>("DUMMY"));

        Callback<TableColumn<Book, String>, TableCell<Book, String>> cellFactory
                = //
                new Callback<TableColumn<Book, String>, TableCell<Book, String>>() {
            @Override
            public TableCell call(final TableColumn<Book, String> param) {
                final TableCell<Book, String> cell = new TableCell<Book, String>() {

                    final Button btn = new Button("Checkout");
                    
                    @Override
                    public void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                            setText(null);
                        } else {    
                        	btn.setOnAction(e -> {
                        		Book book = getTableView().getItems().get(getIndex());
                        		Parent root;
								try {
									FXMLLoader loader = new FXMLLoader(getClass().getResource("FormCheckOut.fxml"));
									root = loader.load();
									Stage primaryStage=new Stage();
	                                primaryStage.setScene(new Scene(root));
	                                BookCheckOutController controller = loader.getController();
	                                controller.initData(book);
	                                	  
	                                root.setOnMousePressed(event -> {
	                                    x = event.getSceneX();
	                                    y = event.getSceneY();
	                                });
	                                root.setOnMouseDragged(event -> {

	                                    primaryStage.setX(event.getScreenX() - x);
	                                    primaryStage.setY(event.getScreenY() - y);

	                                });
	                                primaryStage.setTitle("Check Out Book");
	                                primaryStage.show();
	                               
	                                
								} catch (IOException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}                                
                        	});  
                        	HBox pane = new HBox(btn);
                            setGraphic(pane);
                            //setGraphic(btn); 
                            setText(null);
                        }
                    }
                };
                return cell;
            }
        };

        actionCol.setCellFactory(cellFactory);
        
    	chk_books.setItems(filteredData);
    	chk_books.getColumns().setAll(cTitle,cisbn,cAuthor,cmaxCheckoutLen, cnumOfCopies, availability, actionCol);
    	pnlCheckout.setStyle("-fx-background-color : #53639F");
    	pnlCheckout.toFront();
    }
    
    public void getRecordsView() {
    	ObservableList<CheckoutRecord> data = FXCollections.observableArrayList();        	
    	HashMap<String, CheckoutRecord> map = ctl.getCheckoutRecords();
    	for(Map.Entry<String, CheckoutRecord> m: map.entrySet()) {
    		data.add(m.getValue());
    		
    	}
    	//System.out.println(data);
    	
    	rec_isbn.setCellValueFactory(cellData -> {
    		CheckoutRecord b = cellData.getValue();    		
    		return new SimpleStringProperty(b.getCheckoutRecordEntry().getBookCopy().getBook().getIsbn().toString());
    	});    
    	//bAuthors.setCellValueFactory(new PropertyValueFactory<Book,String>("authors"));
    	rec_memberID.setCellValueFactory(cellData -> {
    		CheckoutRecord b = cellData.getValue();    		
    		return new SimpleStringProperty(b.getMember().getMemberId().toString());
    	});
    	rec_btitle.setCellValueFactory(cellData -> {
    		CheckoutRecord b = cellData.getValue();    		
    		return new SimpleStringProperty(b.getCheckoutRecordEntry().getBookCopy().getBook().getTitle().toString());
    	});
    	rec_bcopynum.setCellValueFactory(cellData -> {
    		CheckoutRecord b = cellData.getValue();    		
    		return new SimpleStringProperty(String.valueOf(b.getCheckoutRecordEntry().getBookCopy().getCopyNum()));
    	});
    	rec_checkoutdate.setCellValueFactory(cellData -> {
    		CheckoutRecord b = cellData.getValue();    		
    		return new SimpleStringProperty(b.getCheckoutRecordEntry().getCheckoutDate().toString());
    	});
    	rec_duedate.setCellValueFactory(cellData -> {
    		CheckoutRecord b = cellData.getValue();    		
    		return new SimpleStringProperty(b.getCheckoutRecordEntry().getDueDate().toString());
    	});
    	
    	FilteredList<CheckoutRecord> filteredData = new FilteredList<>(data, p -> true);
    	rec_SearchBook.textProperty().addListener((observable, oldValue, newValue) -> {
    		filteredData.setPredicate(record -> {
                // If filter text is empty, display all persons.
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                
                // Compare first name and last name of every person with filter text.
                String lowerCaseFilter = newValue.toLowerCase();
                
                if (record.getCheckoutRecordId().toLowerCase().contains(lowerCaseFilter)) {
                    return true; // Filter matches first name.
                } 
                return false; // Does not match.
            });
        });
    	        
        rec_books.setItems(filteredData);
        rec_books.getColumns().setAll(rec_memberID, rec_isbn, rec_btitle, rec_bcopynum, rec_checkoutdate, rec_duedate);
    	pnlCheckoutRecords.setStyle("-fx-background-color : #53639F");
    	pnlCheckoutRecords.toFront();
    }

    public void handleClicks(ActionEvent actionEvent) throws IOException {
    	
    	if (actionEvent.getSource() == btnMembers|| actionEvent.getSource()== rmem) {
        	getMemberView();
        }
        if (actionEvent.getSource() == btnCheckout|| actionEvent.getSource()== rcb) {
        	getCheckoutView();
        	
        }
        if(actionEvent.getSource() == btnBooks|| actionEvent.getSource()== rbook) {
    	   getBooksView();
        }
        if(actionEvent.getSource()==btnCheckoutRecords|| actionEvent.getSource()==rco) {
           getRecordsView();
       	
       }
        if(actionEvent.getSource()==btnLogout)
        {
        	Stage stage = (Stage) btnLogout.getScene().getWindow();
	        stage.close();
	        Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
	        Stage primaryStage=new Stage();
	        primaryStage.setScene(new Scene(root));
	        root.setOnMousePressed(event -> {
	            x = event.getSceneX();
	            y = event.getSceneY();
	        });
	        root.setOnMouseDragged(event -> {

	            primaryStage.setX(event.getScreenX() - x);
	            primaryStage.setY(event.getScreenY() - y);

	        });
	        primaryStage.setTitle("Login");
	        primaryStage.show();
            
        }
    }
    
    public void newMemeber(ActionEvent actionEvent) throws IOException {
    	Parent root = FXMLLoader.load(getClass().getResource("NewMember.fxml"));
        Stage primaryStage=new Stage();
        primaryStage.setScene(new Scene(root));
        root.setOnMousePressed(event -> {
            x = event.getSceneX();
            y = event.getSceneY();
        });
        root.setOnMouseDragged(event -> {

            primaryStage.setX(event.getScreenX() - x);
            primaryStage.setY(event.getScreenY() - y);

        });
        primaryStage.setTitle("Add New Member");
        primaryStage.show();

    }
    
    public void editMemeber(ActionEvent actionEvent) throws IOException {
        	LibraryMember l=tb.getSelectionModel().getSelectedItem();
        	EditMemberController.lmem=l;
        	Parent root = FXMLLoader.load(getClass().getResource("EditMember.fxml"));
            Stage primaryStage=new Stage();
            primaryStage.setScene(new Scene(root));
            root.setOnMousePressed(event -> {
                x = event.getSceneX();
                y = event.getSceneY();
            });
            root.setOnMouseDragged(event -> {

                primaryStage.setX(event.getScreenX() - x);
                primaryStage.setY(event.getScreenY() - y);

            });
            primaryStage.setTitle("Edit Member");
            primaryStage.show();

    }    
    public void newBook(ActionEvent actionEvent) throws IOException {
    	System.out.println("Add a book clicked");
    	Parent root;
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("FormBook.fxml"));
        Stage primaryStage=new Stage();
        //primaryStage.setScene(new Scene(root));
        root = loader.load();    
    	
        root.setOnMousePressed(event -> {
            x = event.getSceneX();
            y = event.getSceneY();
        });
        root.setOnMouseDragged(event -> {

            primaryStage.setX(event.getScreenX() - x);
            primaryStage.setY(event.getScreenY() - y);

        });    	
        primaryStage.setTitle("Add a Book");
        primaryStage.setScene(new Scene(root, 450, 450));
        primaryStage.show();

    }
    
    public void updateBookings() {
    	tb_books.refresh();
    }
    
   
}
