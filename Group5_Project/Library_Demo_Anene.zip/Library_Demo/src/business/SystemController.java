package business;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import business.Book;
import dataaccess.Auth;
import dataaccess.DataAccess;
import dataaccess.DataAccessFacade;
import dataaccess.TestData;
import dataaccess.User;

public class SystemController implements ControllerInterface {
	public static Auth currentAuth = null;
	
	public void login(String id, String password) throws LoginException {
		DataAccess da = new DataAccessFacade();
		HashMap<String, User> map = da.readUserMap();
		if(!map.containsKey(id)) {
			throw new LoginException("ID " + id + " not found");
		}
		String passwordFound = map.get(id).getPassword();
		if(!passwordFound.equals(password)) {
			throw new LoginException("Password incorrect");
		}
		currentAuth = map.get(id).getAuthorization();
		
	}
	@Override
	public List<String> allMemberIds() {
		DataAccess da = new DataAccessFacade();
		List<String> retval = new ArrayList<>();
		retval.addAll(da.readMemberMap().keySet());
		return retval;
	}
	
	@Override
	public List<String> allBookIds() {
		DataAccess da = new DataAccessFacade();
		List<String> retval = new ArrayList<>();
		retval.addAll(da.readBooksMap().keySet());
		return retval;
	}
	
	public List<String> allAuthors(){
		DataAccess da = new DataAccessFacade();
		List<String> retval = new ArrayList<>();
		retval.addAll(da.readUserMap().keySet());
		return retval;
	}
	
	public Author getAuthor(String aName) {
		TestData td = new TestData();
		List<Author> aList =td.allAuthors;
		Author objA = null;
		for(Author a: aList) {
			if(a.getFirstName().equals(aName))
				objA = a;
		}
		return objA;
	}
		
	public void addBook(Book b) {
		System.out.println(b);
	}
	
	@Override
	public HashMap<String, CheckoutRecord> getCheckoutRecords(){
		DataAccess da = new DataAccessFacade();
    	HashMap<String, CheckoutRecord> map = da.readCheckoutRecordMap();
    	return map;
	}
	public void addCheckoutRecord(String recordId, Book book, int copyNum, LocalDate checkoutDate, LocalDate dueDate, LibraryMember member) {
		//CheckoutRecordEntry entryRecord=new CheckoutRecordEntry(recordId, book, copyNum, checkoutDate, dueDate);
		CheckoutRecord record=new CheckoutRecord(recordId, book, copyNum, checkoutDate, dueDate, member);
		DataAccessFacade da=new DataAccessFacade();
		//da.addCheckoutRecord(recordId, book, copyNum, checkoutDate, dueDate);
		da.addCheckoutRecord(record);
	}
	
	
	@Override
	public HashMap<String, LibraryMember> allLibraryMember() {
		DataAccess da = new DataAccessFacade();
    	HashMap<String, LibraryMember> map = da.readMemberMap();
		return map;
	}
	@Override
	public void addNewMember(String memid, String fname, String lname, String tel, String street, String city,
			String state, String zip) {
		Address ad=new Address(street, city,state, zip);
		LibraryMember member=new LibraryMember(memid, fname, lname, tel, ad);
		DataAccessFacade da=new DataAccessFacade();
		da.saveNewMember(member);
	}
	@Override
	public List<Author> getAuthors() {
		TestData td = new TestData();
		return td.allAuthors;
	}
	@Override
	public void addBook(String tfBookIsbn, String tfBookTitle, int maxCheckoutLength, List<Author> authors) {
		DataAccessFacade da=new DataAccessFacade();
		Book b=new Book(tfBookIsbn, tfBookTitle, maxCheckoutLength, authors);
		da.updateBook(b);
	}
	@Override
	public HashMap<String, Book> getBooks() {
		DataAccess da = new DataAccessFacade();
    	HashMap<String, Book> map = da.readBooksMap();
    	return map;
	}
	@Override
	public void addBookCopy(Book b) {
		DataAccess da = new DataAccessFacade();
		da.addBookCopy(b);
		
	}
	@Override
	public Book getBook(String isbn) {
		DataAccess da = new DataAccessFacade();    	
    	return da.getBook(isbn);
	}
	@Override
	public LibraryMember getMember(String memberId) {
		DataAccess da = new DataAccessFacade();    	
    	return da.getMember(memberId);
	}
	@Override
	public void updateBook(Book book) {
		DataAccessFacade da=new DataAccessFacade();
		da.updateBook(book);
	}
	
}
