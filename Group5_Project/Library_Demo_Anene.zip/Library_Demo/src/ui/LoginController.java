package ui;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import business.LoginException;
import business.SystemController;
import dataaccess.Auth;
import dataaccess.DataAccessFacade;
import dataaccess.User;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import util.Messages;


public class LoginController {

	@FXML
	private TextField user_username;
			
	@FXML
	private PasswordField user_password;
	
	@FXML
	private Button login1;
	
	private double x, y;

	@FXML 
	public void onBtnLoginClicked(ActionEvent e) throws IOException {
		try {
			SystemController s=new SystemController();
			s.login((String)user_username.getText(), (String)user_password.getText());
			Stage stage = (Stage) login1.getScene().getWindow();
	        stage.close();
	        Parent root=FXMLLoader.load(getClass().getResource("Home.fxml"));
	        Stage primaryStage=new Stage();
	       /* primaryStage.setScene(new Scene(root));
	        primaryStage.initStyle(StageStyle.UNDECORATED);*/
	        Scene scene = new Scene(root);        
	        scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
	        primaryStage.setScene(scene);
	        primaryStage.initStyle(StageStyle.UNDECORATED);
	        root.setOnMousePressed(event -> {
	            x = event.getSceneX();
	            y = event.getSceneY();
	        });
	        root.setOnMouseDragged(event -> {

	            primaryStage.setX(event.getScreenX() - x);
	            primaryStage.setY(event.getScreenY() - y);

	        });
	        primaryStage.setTitle("Login");
	        primaryStage.show();

		}catch (LoginException ex) {
			// TODO: handle exception
			Messages.showAlertDialog(Alert.AlertType.ERROR, "Error", "ERROR!",
                   ex.getMessage());
		}
		
	}
	@FXML 
	public void onBtnExitClicked(ActionEvent e) {
        Platform.exit();
    }
	
}
