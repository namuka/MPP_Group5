package ui;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.ResourceBundle;

import business.Book;
import business.CheckoutRecord;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.text.Text;

public class CheckoutDetailController implements Initializable {
	
	@FXML
	private Text txtOverdue;	
	@FXML 
	private Text txtMemberid;
	@FXML
	private Text txtBookTitle;
	@FXML
	private Text txtBookIsbn;
	@FXML
	private Text txtCopyNum;
	@FXML
	private Text txtAvailibility;
	@FXML
	private Text txtCheckoutDate;
	@FXML
	private Text txtDueDate;
	

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
	}
	
	public void initData(CheckoutRecord record) {
		txtMemberid.setText(record.getMember().getMemberId());
		txtBookTitle.setText(record.getCheckoutRecordEntry().getBookCopy().getBook().getTitle());
		txtBookIsbn.setText(record.getCheckoutRecordEntry().getBookCopy().getBook().getIsbn());
		txtCopyNum.setText(String.valueOf(record.getCheckoutRecordEntry().getBookCopy().getCopyNum()));
		String availiability = record.getCheckoutRecordEntry().getBookCopy().isAvailable()==true ? "Availiable" : "Not Availiable";
		txtAvailibility.setText(availiability);
		txtCheckoutDate.setText(record.getCheckoutRecordEntry().getCheckoutDate().toString());
		txtDueDate.setText(record.getCheckoutRecordEntry().getDueDate().toString());
		
		String isOverdue;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date d1 =null, d2=null;
		boolean dateOverdue = false;
		try {
			d1 = sdf.parse( record.getCheckoutRecordEntry().getDueDate().toString());
    		d2 = sdf.parse(LocalDate.now().toString());
    		if((d1.compareTo(d2)<0)) dateOverdue = true;
		} catch (Exception e) {
			// TODO: handle exception
		}
    		
		if(record.getCheckoutRecordEntry().getBookCopy().isAvailable() ==false && dateOverdue==true)
			isOverdue = "Overdue!";
		else isOverdue = " ";
		txtOverdue.setText(isOverdue);
	}

}
