package business;

import java.util.ArrayList;
import java.util.List;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

public class BookController {
	@FXML
	private TextField tfTitle;
	@FXML
	private TextField tfISBN;
	@FXML
	private ComboBox<String> comboAuthors;
	@FXML
	private TextField tfMaxCheckoutLength;
	@FXML
	private TextField tfNumOfCopies;
	@FXML
	private Button btnAdd;
	
	public void addBook(ActionEvent e) {
		String title = tfTitle.getText();
		String isbn = tfISBN.getText();
		int maxcheckoutLen = Integer.parseInt(tfMaxCheckoutLength.getText());
		String numCopies = tfNumOfCopies.getText();
		List<Author> authors = new ArrayList<>();
		SystemController ci = new SystemController();
		Author tmp = ci.getAuthor("Joe");
		System.out.println("Combo value: " + tmp);		
		authors.add(tmp);		
		Book newBook = new Book(isbn, title, maxcheckoutLen, authors);
		ci.addBook(newBook);
		
		//System.out.println(title + " " + isbn + " " + maxcheckoutLen + " " + numCopies);
	}
}
