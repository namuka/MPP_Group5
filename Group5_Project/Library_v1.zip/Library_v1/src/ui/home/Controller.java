package ui.home;

import javafx.beans.binding.Bindings;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import business.Address;
import business.Book;
import business.Author;
import business.LibraryMember;
import business.Person;
import dataaccess.DataAccess;
import dataaccess.DataAccessFacade;
import dataaccess.TestData;
import dataaccess.User;
public class Controller implements Initializable {

	@FXML
	private Pane pnlWelcome;
	
    @FXML
    private VBox pnItems = null;
    @FXML
    private Button btnMembers;

    @FXML
    private Button btnBooks;

    @FXML
    private Button btnCheckout;

    @FXML
    private Button btnCheckoutRecord;

    @FXML
    private Button btnSignout;

    @FXML
    private Pane pnlMembers;

    @FXML
    private Pane pnlBooks;

    @FXML
    private Pane pnlCheckout;

    @FXML
    private Pane pnlCheckoutRecord;
    
    @FXML
    private TableView<LibraryMember> tb;
    @FXML
    private TableColumn<LibraryMember, String> fname;
    @FXML
    private TableColumn<LibraryMember, String> lname;
    @FXML
    private TableColumn<LibraryMember, String> telephone;
    
    @FXML TableView<Book> tb_books;
    @FXML
    private TableColumn<Book, String> bTitle;
    @FXML
    private TableColumn<Book, String> isbn;
    @FXML
    private TableColumn<Book, String> bAuthors;
    @FXML
    private TableColumn<Book, Integer> maxCheckoutLen;
    @FXML
    private TableColumn<Book, Integer> numOfCopies; 
    @FXML
    private TextField tfSearchBook;
    @FXML
    private Button btnSearchBook;
    @FXML
	private TextField tfBookTitle;
    @FXML
    private TextField tfBookIsbn;
    @FXML
    private TextField tfBookCopies;
    @FXML
    private TextField tfBookMax;
    @FXML
    private ListView<Author> lvBookAuthors;
    //private ChoiceBox<Author> choiceBookAuthors;
    //private ComboBox<Author> comboBookAuthors;
    
    @FXML
    private Button btnBookFormCancel;
    @FXML
    private Button btnBookFormSave;
    @FXML
    private Text txtBookForm;
    @FXML
    private Button btnBookAddCopy;
    @FXML
    private Button btnAddBook;

    @Override
    public void initialize(URL location, ResourceBundle rsoeurces) {
  
    	//pnlWelcome.setStyle("-fx-background-color : #53639F");
    	//pnlWelcome.toFront();
    }

    
    public void handleClicks(ActionEvent actionEvent) {
    	
    	//show library members
        if (actionEvent.getSource() == btnMembers) {
        	ObservableList<LibraryMember> data = FXCollections.observableArrayList();
        	
        	DataAccess da = new DataAccessFacade();
        	HashMap<String, LibraryMember> map = da.readMemberMap();
        	for(Map.Entry<String, LibraryMember> m: map.entrySet()) {
        		data.add(m.getValue());
        		
        	}
        	//System.out.println(data);
        	//fname = new TableColumn<LibraryMember,String>("fname");
        	fname.setCellValueFactory(new PropertyValueFactory<LibraryMember,String>("firstName"));
        	//lname = new TableColumn<LibraryMember,String>("lname");
        	lname.setCellValueFactory(new PropertyValueFactory<LibraryMember,String>("lastName"));
        	//telephone = new TableColumn<LibraryMember,String>("telephone");
        	telephone.setCellValueFactory(new PropertyValueFactory<LibraryMember,String>("telephone"));
        	
        	
        	tb.setItems(data);
        	tb.getColumns().setAll(fname,lname,telephone);
        	//pnlMembers.setStyle("-fx-background-color : #53639F");
        	pnlMembers.toFront();
        	pnlMembers.setStyle("-fx-background-color : #53639F");
        	pnlMembers.toFront();
        }
        if(actionEvent.getSource() == btnBooks) {
        	ObservableList<Book> data = FXCollections.observableArrayList();        	
        	DataAccess da = new DataAccessFacade();
        	HashMap<String, Book> map = da.readBooksMap();
        	for(Map.Entry<String, Book> m: map.entrySet()) {
        		data.add(m.getValue());
        		
        	}
        	//System.out.println(data);
        	
        	bTitle.setCellValueFactory(new PropertyValueFactory<Book,String>("title"));
        	isbn.setCellValueFactory(new PropertyValueFactory<Book,String>("isbn"));
        	//bAuthors.setCellValueFactory(new PropertyValueFactory<Book,String>("authors"));
        	bAuthors.setCellValueFactory(cellData -> {
        		Book b = cellData.getValue();
        		List<Author> alist = b.getAuthors();
        		StringBuilder authorNames = new StringBuilder();
        		int i=0;
        		for(Author a: alist) {
        			if(i==0)
        			authorNames.append(a.getFirstName() + " " + a.getLastName());
        			else authorNames.append(", " + a.getFirstName() + " " + a.getLastName());
        			
        			i +=1;
        		}
        		return new SimpleStringProperty(authorNames.toString());
        	});
        	maxCheckoutLen.setCellValueFactory(new PropertyValueFactory<Book,Integer>("maxCheckoutLength"));
        	numOfCopies.setCellValueFactory(cellData -> {
        		Book b = cellData.getValue();
        		return new SimpleIntegerProperty(b.getNumCopies()).asObject();
        	});
        	
        	FilteredList<Book> filteredData = new FilteredList<>(data, p -> true);
        	tfSearchBook.textProperty().addListener((observable, oldValue, newValue) -> {
        		filteredData.setPredicate(book -> {
                    // If filter text is empty, display all persons.
                    if (newValue == null || newValue.isEmpty()) {
                        return true;
                    }
                    
                    // Compare first name and last name of every person with filter text.
                    String lowerCaseFilter = newValue.toLowerCase();
                    
                    if (book.getIsbn().toLowerCase().contains(lowerCaseFilter)) {
                        return true; // Filter matches first name.
                    } 
                    return false; // Does not match.
                });
            });
        	
        	
        	TableColumn actionCol = new TableColumn("Action");
            actionCol.setCellValueFactory(new PropertyValueFactory<>("DUMMY"));

            Callback<TableColumn<Book, String>, TableCell<Book, String>> cellFactory
                    = //
                    new Callback<TableColumn<Book, String>, TableCell<Book, String>>() {
                @Override
                public TableCell call(final TableColumn<Book, String> param) {
                    final TableCell<Book, String> cell = new TableCell<Book, String>() {

                        final Button btn = new Button("Edit");
                        final Button btn2 = new Button("Add a copy");

                        @Override
                        public void updateItem(String item, boolean empty) {
                            super.updateItem(item, empty);
                            if (empty) {
                                setGraphic(null);
                                setText(null);
                            } else {
                                btn.setOnAction(event -> {
                                	Book book = getTableView().getItems().get(getIndex());
                                    //System.out.println(book.getIsbn() + "   " + book.getTitle());                                    
                                    Parent addDialog;
                                    try {  
                                    	Stage popupwindow=new Stage();	
                                    	FXMLLoader loader = new FXMLLoader(getClass().getResource("/ui/home/FormBook.fxml"));                                    
                                    	//root = FXMLLoader.load(getClass().getResource("/ui/home/FormBook.fxml"));
                                    	addDialog = loader.load();
                                    	Controller controller = loader.getController();
                                    	TextField tf1 = controller.tfBookTitle;                                    	
                                    	tf1.setText(book.getTitle());
                                    	TextField tf2 = controller.tfBookIsbn;                                    	
                                    	tf2.setText(book.getIsbn());
                                    	TextField tf3 = controller.tfBookCopies;                                    	
                                    	tf3.setText(String.valueOf(book.getNumCopies()));
                                    	tf3.setDisable(true);
                                    	TextField tf4 = controller.tfBookMax;                                    	
                                    	tf4.setText(String.valueOf(book.getMaxCheckoutLength()));
                                    	
                                    	ListView<Author> tf5 = controller.lvBookAuthors;  
                                    	tf5.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
                                    	final ObservableList<Author> strings = FXCollections.observableArrayList();  
                                    	TestData td = new TestData();
                                    	List<Author> allAuthors = td.allAuthors;
                                    	int i = 0; 
                                    	List<Author> alist = book.getAuthors();
                                    	for(Author a: allAuthors) {
                                    		 strings.add(a);                                    		 
                                 		}                                    	
                                    	tf5.setItems(strings);
                                    	for(Author a: allAuthors) {                                   		 
                                   		 for(Author a2: alist) {
                                   			 if(a.getFirstName().equals(a2.getFirstName())) {
                                   				tf5.getSelectionModel().select(i);
                                   			 }
                                   		 }
                                   		 i+=1;
                                		}           
                                    	
                                    	Button btnCancel = controller.btnBookFormCancel;
                                    	TableView<Book> tbBooksInner = controller.tb_books;
                                    	btnCancel.setOnAction(e -> {
                                    		popupwindow.close();
                                    		//tbBooksInner.refresh();                                    		
                                    		/*final ObservableList<Book> data = FXCollections.observableArrayList();        	
                                        	DataAccess da = new DataAccessFacade();
                                        	HashMap<String, Book> map = da.readBooksMap();
                                        	for(Map.Entry<String, Book> m: map.entrySet()) {
                                        		data.add(m.getValue());
                                        		
                                        	}
                                        	controller.tb_books.getItems().clear();
                                        	controller.tb_books.getItems().addAll(data);*/
                                        	tb_books.refresh();
                                    	});
                                    	
                                    	Button btnSave = controller.btnBookFormSave;
                                    	btnSave.setOnAction(e -> {
                                    		List<Author> alist2 = new ArrayList<>();
                                    		//System.out.println(tf5.getSelectionModel().getSelectedItems());
                                    		for(Author a2: tf5.getSelectionModel().getSelectedItems()) {                                    			
                                    			alist2.add(a2);
                                    			
                                    		}
                                    		Book newBook = new Book(tf2.getText(),tf1.getText(), Integer.parseInt(tf4.getText()), alist2);
                                    		da.updateBook(newBook);
                                    		//System.out.println(newBook);
                                    		txtBookForm = controller.txtBookForm;
                                    		//txtBookForm.setStyle("-fx-background-color : #e1ecf4");
                                    		txtBookForm.setStyle("-fx-background-color: #E1ECF4;");
                                    		txtBookForm.setText("Successfully saved!");
                                    		
                                    		//TableView<Book> tbBooksInner = controller.tb_books;
                                    		//tbBooksInner.refresh();
                                    		/*final ObservableList<Book> data = FXCollections.observableArrayList();        	
                                        	DataAccess da = new DataAccessFacade();
                                        	HashMap<String, Book> map = da.readBooksMap();
                                        	for(Map.Entry<String, Book> m: map.entrySet()) {
                                        		data.add(m.getValue());
                                        		
                                        	}
                                    	    controller.tb_books.getItems().clear();
                                    	    controller.tb_books.getItems().addAll(data);*/
                                    		tb_books.refresh();
                                    	});                                    	
                                    	
                                    	popupwindow.initOwner(this.getScene().getWindow());
                                    	popupwindow.initModality(Modality.APPLICATION_MODAL);                                    	
                                        //Stage stage = new Stage();
                                    	popupwindow.setTitle("Book information");
                                    	popupwindow.setScene(new Scene(addDialog, 450, 450));
                                    	popupwindow.showAndWait();
                                        // Hide this current window (if this is what you want)
                                        //((Node)(event.getSource())).getScene().getWindow().hide();                                    	
                                    }
                                    catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                   
                                });
                                btn.setStyle("-fx-padding: 5px"); 
                                
                                btn2.setOnAction(e -> {
                                	Book book = getTableView().getItems().get(getIndex());
									da.addBookCopy(book);
									Alert alert =  new Alert(AlertType.INFORMATION);
									alert.setTitle("Add a book copy information");
									alert.setContentText("Successfully added.");
									alert.showAndWait();
									
									tb_books.refresh();
	                            	
                                });
                                HBox.setMargin(btn2,new Insets(0,5,0,10));                               
                                HBox pane = new HBox(btn, btn2);
                                setGraphic(pane);
                                //setGraphic(btn); 
                                setText(null);
                                
                                
                            }
                        }
                    };
                    return cell;
                }
            };

            actionCol.setCellFactory(cellFactory);
            
        	tb_books.setItems(filteredData);
        	tb_books.getColumns().setAll(bTitle,isbn,bAuthors,maxCheckoutLen, numOfCopies, actionCol);
        	pnlBooks.setStyle("-fx-background-color : #53639F");
        	pnlBooks.toFront();
        }
        if(actionEvent.getSource()== btnAddBook) {
        	
        	Parent addDialog;
            try {  
            	DataAccess da = new DataAccessFacade();
            	
            	Stage popupwindow=new Stage();	
            	FXMLLoader loader = new FXMLLoader(getClass().getResource("/ui/home/FormBook.fxml"));                                    
            	//root = FXMLLoader.load(getClass().getResource("/ui/home/FormBook.fxml"));
            	addDialog = loader.load();            
            	Controller controller = loader.getController();
            	TextField tf1 = controller.tfBookTitle;
            	TextField tf2 = controller.tfBookIsbn; 
            	TextField tf3 = controller.tfBookCopies;
            	tf3.setText("1");
            	tf3.setDisable(true);
            	TextField tf4 = controller.tfBookMax;   
            	
            	ListView<Author> tf5 = controller.lvBookAuthors;  
            	tf5.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
            	final ObservableList<Author> strings = FXCollections.observableArrayList();  
            	TestData td = new TestData();
            	List<Author> allAuthors = td.allAuthors;            	
            	for(Author a: allAuthors) {
            		 strings.add(a);                                    		 
         		}                                    	
            	tf5.setItems(strings);
            	
            	Button btnCancel = controller.btnBookFormCancel;
            	btnCancel.setOnAction(e -> {
            		popupwindow.close();
            		
                	tb_books.refresh();
            	});
            	
            	Button btnSave = controller.btnBookFormSave;
            	btnSave.setOnAction(e -> {
            		List<Author> alist2 = new ArrayList<>();
            		//System.out.println(tf5.getSelectionModel().getSelectedItems());
            		for(Author a2: tf5.getSelectionModel().getSelectedItems()) {                                    			
            			alist2.add(a2);
            			
            		}
            		Book newBook = new Book(tf2.getText(),tf1.getText(), Integer.parseInt(tf4.getText()), alist2);
            		da.updateBook(newBook);
            		//System.out.println(newBook);
            		txtBookForm = controller.txtBookForm;
            		txtBookForm.setStyle("-fx-background-color: #E1ECF4;");
            		txtBookForm.setText("Successfully saved!");
            		
            		tb_books.refresh();
            	}); 
            	
            	
            	popupwindow.initModality(Modality.APPLICATION_MODAL);                                    	
                //Stage stage = new Stage();
            	popupwindow.setTitle("Add a book");
            	popupwindow.setScene(new Scene(addDialog, 450, 450));
            	popupwindow.showAndWait();
            }catch(IOException ex) {
            	ex.printStackTrace();
            }
        }
       /* if (actionEvent.getSource() == btnMenus) {
            pnlMenus.setStyle("-fx-background-color : #53639F");
            pnlMenus.toFront();
        }
       /* if (actionEvent.getSource() == btnOverview) {
            pnlOverview.setStyle("-fx-background-color : #02030A");
            pnlOverview.toFront();
        }
        if(actionEvent.getSource()==btnOrders)
        {
            pnlOrders.setStyle("-fx-background-color : #464F67");
            pnlOrders.toFront();
        }*/
        if(actionEvent.getSource()==btnSignout)
        {
           // pnlOrders.setStyle("-fx-background-color : #464F67");
           // pnlOrders.toFront();
            System.exit(0);
        }
    }
}
